#include "funcs.h"

int main(int argc, char** argv)
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);

	string str, substr;
	
	if(argc > 1) {
		str = argv[1];
		cout << "Подстрока дял поиска: ";
		cin >> substr;
		findSubstr(str, substr);
		return EXIT_SUCCESS;
	}

	cout << "Введите строку: ";
	cin >> str;
	cout << "Подстрока для поиска: ";
	cin  >> substr;
	while (cin.get() != '\n');
	findSubstr(str, substr);
	
	cout << "Введите строку: ";
	getline(cin, str);

	getStringStatistics(str);

	system("pause");
	return EXIT_SUCCESS;
}
