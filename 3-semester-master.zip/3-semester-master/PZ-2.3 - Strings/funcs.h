#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <windows.h>

using namespace std;

void findSubstr(const string& str, const string& substr)
{
	int i = 0, pos = 0, cur_pos = 0, count = 0;
	string s = str;

	while (i != str.length())
	{
		cur_pos = s.find(substr);
		if (!(cur_pos + 1))	break;
		pos += cur_pos;
		s = s.substr(cur_pos + 1, s.length() - cur_pos);
		cout << str << endl;

		for (int t = 0; t < pos; t++)
			cout << ' ';

		cout << "| - " << pos << endl;
		pos++;
		count++;

		if (++i != str.length());
		else break;
	}
	cout << "Количество вхождений - " << count << endl;
}

void getStringStatistics(const string& s)
{
	vector<pair<char, int>> vecSt;
	char num[] = { "аоеиёуэюяы" };

	for (int i = 0; i < 10; i++)
		vecSt.emplace_back(num[i], 0);

	for (int i = 0; i < vecSt.size(); i++) {
		int t = count_if(s.begin(), s.end(), [i, vecSt](char c)->bool {
			return (c == vecSt[i].first);	});
		vecSt[i].second = t;
	}

	cout << "Статистика строки:" << endl;
	for (int i = 0; i < vecSt.size(); i++)
		cout << "Буква '" << vecSt[i].first << "' встречается " << vecSt[i].second << " раз." << endl;

	cout << "Количество слов - " << count(s.begin(), s.end(), ' ') + 1 << endl;
}
