#pragma once

#include <iostream>
#include <fstream>
#include <iomanip>
#include <windows.h>
#include "json.h"

using namespace std;
using json = nlohmann::json;

namespace product
{
	struct Product
	{
		int ID;
		string type;
		int price;
		int quantity;
	};
	//-----------------------------------------------------------------------------------------------------
	//Проверка наличия файла
	bool getFileName(string &file_name)
	{
		cout << "Введите название файла: ";
		cin >> file_name;
		fstream f(file_name, ios_base::in);
		if (f.is_open()) {
			f.close();
			return true;
		}
		else {
			cout << "Ошибка: файл не найден.\n";
			return false;
		}
	}
	//-----------------------------------------------------------------------------------------------------
	//Безопасный ввод
	template <typename T>
	void safeEnter(T &value)
	{
		while (!(cin >> value))
		{
			cin.clear();
			while (cin.get() != '\n') continue;
			cout << "Ошибка ввода - попробуйте еще раз: ";
		}
	}
	//-----------------------------------------------------------------------------------------------------
	//Инициализировать структуру и модель
	void getProduct(string& model, Product& obj, const int& ID = 0)
	{
		if (!ID)
		{
			cout << "Введите ID товара: ";
			safeEnter(obj.ID);
		}
		else
			obj.ID = ID;

		cout << "Тип комплектующей: ";
		while (cin.get() != '\n');
		getline(cin, obj.type);

		cout << "Модель: ";
		getline(cin, model);

		cout << "Цена (руб./ед): ";
		safeEnter(obj.price);

		cout << "Количеcтво: ";
		safeEnter(obj.quantity);
	}
	//Конвертировать структуру и модель товара в JSON обьект
	void to_json(json& j, const string& model, const Product& p)
	{
		j = json{ { "ID", p.ID },{ "type", p.type },{ "model", model },{ "price", p.price },{ "quantity", p.quantity } };
	}
	//-----------------------------------------------------------------------------------------------------
	//Конвертировать JSON обьект в структуру и модель товара
	void from_json(const json& j, string& model, Product& p)
	{
		p.ID = j.at("ID").get<int>();
		p.type = j.at("type").get<string>();
		model = j.at("model").get<string>();
		p.price = j.at("price").get<int>();
		p.quantity = j.at("quantity").get<int>();
	}
	//-----------------------------------------------------------------------------------------------------
	//Считывание файла в контейнер JSON
	json getFileContent(ifstream* f)
	{
		json arrJ;
		*f >> arrJ;
		return arrJ;
	}
	//-----------------------------------------------------------------------------------------------------
	bool checkID(const int& ID, const multimap<string, Product>& mapProd)
	{
		for (auto it : mapProd)
			if (ID == it.second.ID)
				return true;
		
		return false;
	}
	//-----------------------------------------------------------------------------------------------------
	//Проверка наличия в файле товаров с указанным ID (true, если есть)
	bool checkID(const int& ID, const string& file_name)
	{
		ifstream f(file_name, ios_base::in);
		json arrJ = getFileContent(&f);
		f.close();

		for (auto j : arrJ)
		{
			if (ID == j.at("ID"))
				return true;
		}
		return false;
	}
}
