#include "Database.h"

int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);

	cout << "Магазин \"Комплектующие ПК\"" << endl;
	Database a;
	a.database();

	return 0;
}
