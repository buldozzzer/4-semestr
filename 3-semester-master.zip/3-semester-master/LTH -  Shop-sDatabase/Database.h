#include "product.h"

using namespace product;

class Database
{
private:
	string model;
	Product obj;
	multimap<string, Product> mapProducts;  
	bool file_open = false; //идентификатор открытия файла
	//-----------------------------------------------------------------------------------------------------
	//Добавить в файл объект
	void addProduct()
	{
		//string file_name;
		//while (!getFileName(file_name));

		int ID;
		cout << "Введите ID товара: ";
		safeEnter(ID);
		//while (checkID(ID, file_name))
		while (checkID(ID, mapProducts))
		{
			cout << "Ошибка - товар с введенным ID уже существует. Попробуйте еще раз: ";
			safeEnter(ID);
		}

		getProduct(model, obj, ID);
		mapProducts.insert(pair<string, Product>(model, obj));
		//json j;
		//to_json(j, model, obj);

		//ofstream f(file_name, ios_base::out | ios_base::app);
		//f << j << '\n';
		//f.close();
	}
	//-----------------------------------------------------------------------------------------------------
	//Напечатать информацию о товаре
	void printProduct(multimap<string, Product>::iterator it)
	{
		cout << "------------------------------------------------------------" << endl
			 << setw(6)  << left << it->second.ID                              << '|'
			 << setw(15) << left << it->second.type                            << '|'
			 << setw(15) << left << it->first                                  << '|'
			 << setw(10) << left << it->second.price                           << '|'
			 << setw(10) << left << it->second.quantity                        << endl;
	}
	//-----------------------------------------------------------------------------------------------------
	//Загрузить базу данных из файла
	int downloadDatabase()
	{
		string file_name;
		if (!getFileName(file_name)) return 0;

		ifstream f(file_name, ios_base::in);
		json arrJ = getFileContent(&f);
		f.close();

		vector<string> vecModel(0);
		vector<Product> vecProducts(0);

		for (int i = 0; i < arrJ.size(); i++)
		{
			vecModel.emplace_back();
			vecProducts.emplace_back();
			from_json(arrJ[i], vecModel[i], vecProducts[i]);
		}

		for (int i = 0; i < arrJ.size(); i++)
			this->mapProducts.insert(pair <string, Product>(vecModel[i], vecProducts[i]));

		cout << "Данные успешно загружены." << endl;
		return 0;
	}
	//-----------------------------------------------------------------------------------------------------
	//Напечатать всю базу данных
	void printDatabase()
	{
		cout << "ID    |Тип товара     |Модель         |Цена      |Количество" << endl;
		for (auto it = mapProducts.begin(); it != mapProducts.end(); it++)
			printProduct(it);
	}
	//-----------------------------------------------------------------------------------------------------
	//Сохранить базу данных в файл
	void saveDatabase()
	{
		string file_name;
		cout << "Введите название файла: ";
		cin >> file_name;

		json arrJ, j;
		ofstream f(file_name, ios_base::out | ios_base::trunc);
		for (auto it = mapProducts.begin(); it != mapProducts.end(); it++) {
			if (it->second.quantity != 0) {
				to_json(j, it->first, it->second);
				arrJ.emplace_back(j);
			}
		}
		f << arrJ.dump(4);
		f.close();

		mapProducts.clear();
		cout << "Данные успешно сохранены в " << file_name << "." << endl;
	}
	//-----------------------------------------------------------------------------------------------------
	//Искать товары в определенном ценовом диапозоне
	void searchInPriceRange()
	{
		int minPrice, maxPrice;
		cout << "Укажите ценовой диапозон.\nМинимальная цена: " ;
		safeEnter(minPrice);
		if (minPrice < 0)
		{
			cout << "Ошибка ввода - попробуйте еще раз: ";
			safeEnter(minPrice);
		}

		cout << "Максимальная цена: ";
		safeEnter(maxPrice);
		while (maxPrice < minPrice)
		{
			cout << "Ошибка ввода - попробуйте еще раз: ";
			safeEnter(maxPrice);
		}

		bool product_exist = false;                                         //Проверка наличия
		for (auto it : mapProducts)                                         //товаров из 
			if (it.second.price >= minPrice && it.second.price <= maxPrice) //введенного
				product_exist = true;                                       //ценового диапозона

		if (product_exist)
		{
			cout << "ID    |Тип товара     |Модель         |Цена      |Количество" << endl;
			for (auto it = mapProducts.begin(); it != mapProducts.end(); it++)
				if (it->second.price >= minPrice && it->second.price <= maxPrice)
					printProduct(it);
		}
		else
			cout << "Товары из введенного ценового диапозона не найдены." << endl;
	}
	//-----------------------------------------------------------------------------------------------------
	//Искать определенный тип товаров
	void searchCurentType()
	{
		string type;
		cout << "Введите тип товара: ";
		while (cin.get() != '\n');
		getline(cin, type);

		bool product_exist = false;     //Проверка наличия
		for (auto it : mapProducts)     //товаров  
			if (it.second.type == type) //введенного
				product_exist = true;   //типа

		if (product_exist)
		{
			cout << "ID    |Тип товара     |Модель         |Цена      |Количество" << endl;
			for (auto it = mapProducts.begin(); it != mapProducts.end(); it++)
				if (it->second.type == type)
					printProduct(it);
		}
		else
			cout << "Товары введенного типа не найдены." << endl;
	}
	//-----------------------------------------------------------------------------------------------------
	//Купить товар
	int buyProduct()
	{
		int ID;
		cout << "Введите код приобретаемого товара: ";
		safeEnter(ID);

		bool product_exist = false;
		for (auto it : mapProducts)
			if (it.second.ID == ID)
				product_exist = true;

		if (!product_exist)
		{
			cout << "Товар с введенным ID не найден." << endl;
			return 0;
		}
		
		auto it = mapProducts.begin();
		while (it->second.ID != ID)
			it++;
		
		int qnt = 0;
		cout << "Введите количество приобретаемого товара: ";
		safeEnter(qnt);

		while (qnt < 1 || qnt > it->second.quantity)
		{
			if (qnt < 1) {
				cout << "Ошибка ввода - попробуйте еще раз: ";
				safeEnter(qnt);
			}
			if (qnt > it->second.quantity) {
				cout << "На складе доступно лишь " << it->second.quantity << " единиц товара." << endl;
				return 0;
			}
		}

		it->second.quantity -= qnt;
		cout << "Товар успешно приобретен." << endl;

		return 0;
	}
	//-----------------------------------------------------------------------------------------------------
public:
	//-----------------------------------------------------------------------------------------------------
	int menu()
	{
		int choose;
		cout << "\n1. Загрузка базы данных из файла"           << endl
		     << "2. Добавить новый товар в базу"               << endl
		     << "3. Вывод всех товаров, находящихся на складе" << endl
		     << "4. Поиск товара по типу"                      << endl
		     << "5. Поиск товара из ценового диапозона"        << endl
		     << "6. Купить товар"                              << endl
		     << "7. Сохранить базу данных в файл"              << endl
		     << "8. Выйти из программы"                        << endl
		     << "\nВыберите действие: ";
		safeEnter(choose);
		return choose;
	}
	//-----------------------------------------------------------------------------------------------------
	void database()
	{
		int choose;
		do
		{
			choose = menu();
			switch (choose)
			{
			case 1: downloadDatabase();
				this->file_open = true;
				break;
			case 2: if (file_open) addProduct();
					else cout << "База данных не загружена.\n";
				break;
			case 3: if (file_open) printDatabase();
					else cout << "База данных не загружена.\n";
				break;
			case 4: if (file_open) searchCurentType();
					else cout << "База данных не загружена.\n";
				break;
			case 5: if (file_open) searchInPriceRange();
					else cout << "База данных не загружена.\n";
				break;
			case 6: if (file_open) buyProduct();
					else cout << "База данных не загружена.\n";
				break;
			case 7:	if (file_open) {
				saveDatabase();
				file_open = false; }
					else cout << "База данных не загружена.\n";
				break;
			case 8:
				break;
			}
		} while (choose != 8);
	}
};
