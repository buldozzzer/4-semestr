#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <list>
#include <algorithm>
#include <windows.h>

using namespace std;

//Безопасный ввод
template <typename T>
void safeEnter(T &value)
{
	while (!(cin >> value))	{
		cin.clear();
		while (cin.get() != '\n') continue;
		cout << "Ошибка ввода. Попробуйте еще раз: ";
	}
}

//Проверка наличия файла
bool getFileName(string &file_name)
{
	cout << "Enter file name: ";
	cin >> file_name;
	fstream f(file_name, ios_base::in);
	if (f.is_open()) {
		f.close();
		return true;
	}
	else {
		cout << "Error opening file. Repeat input.\n\n";
		return false;
	}
}

int menu()
{
	int choose;
	cout << "\n1. Loading data from file\n"
		 << "2. Counting the total number of words\n"
		 << "3. Print unique words in ascending order\n"
		 << "4. Counting words starting with a given letter\n"
		 << "5. Print words starting with a given letter\n"
		 << "6. Sort words by descending length and display\n"
		 << "7. Exit programm\n"
		 << "\nSelect an action: ";
	safeEnter(choose);
	return choose;
}

void downloadFile(list<string>& listStr)
{
	string file_name;
	while (!getFileName(file_name));

	ifstream f(file_name, ios_base::in);
	string s;

	char smb[] = { "():;.?!-'/,\"0123456789" };

	while (getline(f, s, ' ')) {
		for (int i = 0; i < strlen(smb); i++)
			s.erase(remove(s.begin(), s.end(), smb[i]));
		if (!s.empty())
			listStr.emplace_back(s);
	}	

	cout << "Data has been successfully uploaded." << endl;
}

void countWords(list<string> listStr) {	cout << "Total number of words - " << listStr.size() << endl; }

void printUniqueWords(list<string> listStr)
{
	listStr.sort();
	listStr.unique();

	multimap<int, string> map;
	for (auto it : listStr)
		map.insert(pair<int, string>(it.length(), it));

	for_each(map.rbegin(), map.rend(), [](pair<int, string> s) { cout << s.second << endl; });
}

void countCurentWords(list<string> listStr)
{
	char c;
	cout << "Enter a letter: ";
	cin  >> c;
	cout << "Number of words starting with a letter \"" << c << "\" - "
		 << count_if(listStr.begin(), listStr.end(), [c](string s)->bool { return c == s[0]; })
		 << endl;
}

void printCurentWords(list<string> listStr)
{
	char c;
	cout << "Enter a letter: ";
	cin >> c;
	for_each(listStr.begin(), listStr.end(), [c](string s) {
		if (c == s[0])
			cout << s << endl; });
}

void sortByLength(list<string>& listStr)
{
	multimap<int, string> map;
	for (auto it : listStr)
		map.insert(pair<int, string>(it.length(), it));
	for_each(map.begin(), map.end(), [](pair<int, string> map) {cout << map.second << endl; });
}
