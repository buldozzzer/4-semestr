#include "funcs.h"

int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);

	list<string> listStr;
	int choise;

	do
	{
		choise = menu();
		switch (choise)
		{
		case 1: downloadFile(listStr);
			break;
		case 2: countWords(listStr);
			break;
		case 3: printUniqueWords(listStr);
			break;
		case 4: countCurentWords(listStr);
			break;
		case 5: printCurentWords(listStr);
			break;
		case 6: sortByLength(listStr);
			break;
		case 7:
			break;
		default:
			break;
		}
	} while (choise != 7);

	return EXIT_SUCCESS;
}
