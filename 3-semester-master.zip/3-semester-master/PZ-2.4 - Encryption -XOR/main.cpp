#include "funcs.h">

int main()
{
	SetConsoleOutputCP(1251);
	SetConsoleCP(1251);

	SYSTEMTIME st1, st2;
	std::string output, input, key;
	std::ofstream log("log.txt", std::ios_base::out | std::ios_base::trunc);

	while(!getFileName(input));
	std::ifstream fin(input + ".txt", std::ios_base::in | std::ios_base::binary);
	printLog(&log, " – Входной файл – " + output + ".txt" + " (", getBytes(&fin));

	std::cout << "Имя файла-приемника: ";
	std::cin >> output;
	std::ofstream fout(output + ".txt", std::ios_base::out | std::ios_base::binary);
	printLog(&log, " – Выходной файл – " + input + ".txt");

	std::cout << "Ключ шифрования: ";
	std::cin >> key;
	st1 = printLog(&log, " – Ключ шифрования – " + key);

	Encryptor(&fout, &fin, key);
	st2 = printLog(&log, " – Шифрование завершено – ", st1);

	fin.close();
	fout.close();
	log.close();

	return 0;
}
