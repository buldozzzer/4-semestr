#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <windows.h>

void Encryptor(std::ofstream* fout, std::ifstream* fin, const std::string& key)
{
	fin->seekg(0, SEEK_SET);
	unsigned char c = fin->get();
	bool b = true;

	while(b)
		for (auto k : key) {
			fout->put((unsigned char)(k ^ c));
			c = fin->get();
			if (fin->eof()) {
				b = false;
				break;
			}
		}
}

bool getFileName(std::string &file_name)
{
	std::cout << "Имя файла-источника: ";
	std::cin >> file_name;
	std::ofstream f(file_name + ".txt", std::ios_base::in);
	if (f.is_open()) {
		f.close();
		return true;
	}
	else {
		std::cout << "Ошибка открытия файла. Повторите ввод.\n\n";
		return false;
	}
}

SYSTEMTIME printLog(std::ofstream* log, std::string s)
{
	SYSTEMTIME st;
	GetLocalTime(&st);
	*log << "[" << std::setw(2) << st.wDay  << "."  << std::setw(2) << st.wMonth  << "."  << st.wYear
		 << " " << std::setw(2) << st.wHour << ":"  << std::setw(2) << st.wMinute << ":"  << st.wSecond
		 << ":" << std::setw(3) << st.wMilliseconds <<      "]"     <<      s     << '\n';
	return st;
}

SYSTEMTIME printLog(std::ofstream* log, std::string s, int bytes)
{
	SYSTEMTIME st;
	GetLocalTime(&st);
	*log << "[" << std::setw(2) << st.wDay   << "." << std::setw(2) << st.wMonth  <<  "."  << st.wYear
		 << " " << std::setw(2) << st.wHour  << ":" << std::setw(2) << st.wMinute <<  ":"  << st.wSecond
		 << ":" << std::setw(3) << st.wMilliseconds <<      "]"     <<      s     << bytes << " байт)\n";
	return st;
}

SYSTEMTIME printLog(std::ofstream* log, std::string s, SYSTEMTIME st1)
{
	SYSTEMTIME st;
	GetLocalTime(&st);
	*log << "[" << std::setw(2) << st.wDay   << "." << std::setw(2) << st.wMonth  << "." << st.wYear
	 	 << " " << std::setw(2) << st.wHour  << ":" << std::setw(2) << st.wMinute << ":" << st.wSecond
		 << ":" << std::setw(3) << st.wMilliseconds << "]" <<   s   << st.wMilliseconds - st1.wMilliseconds
		 << " мс\n";
	return st;
}

int getBytes(std::ifstream* file)
{
	file->seekg(0, SEEK_END);
	int bytes = (int)file->tellg();
	file->seekg(0, SEEK_SET);
	return bytes;
}
