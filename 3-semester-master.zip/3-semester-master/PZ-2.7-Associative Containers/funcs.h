#pragma once

#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>
#include <windows.h>

using namespace std;

//Проверка наличия файла
bool getFileName(string &file_name)
{
	cout << "Введите название файла: ";
	cin >> file_name;
	fstream f(file_name, ios_base::in);
	if (f.is_open()) {
		f.close();
		return true;
	}
	else {
		cout << "Ошибка открытия файла. Повторите ввод.\n\n";
		return false;
	}
}
//-----------------------------------------------------------------------------------------------------
//Безопасный ввод
template <typename T>
void safeEnter(T &value)
{
	while (!(cin >> value))
	{
		cin.clear();
		while (cin.get() != '\n') continue;
		cout << "Ошибка ввода - попробуйте еще раз: ";
	}
}
//-----------------------------------------------------------------------------------------------------
int menu()
{
	int choise;
	cout << "\n1. Добавить результаты аттестации из файла\n"
		 << "2. Вывесть оценки всех студентов на экран\n"
		 << "3. Вывести общее число оценок каждого студента\n"
		 << "4. Вывести студентов, у которых есть долги или оценки «2»\n"
		 << "5. Вывести результат аттестации для каждого студента\n"
		 << "6. Выйти из программы\n"
	 	 << "\nВыберите действие: ";
	safeEnter(choise);
	return choise;
}
//-----------------------------------------------------------------------------------------------------
void downloadDatabase(multimap<string, int>& mapSt)
{
	string file_name;
	while (!getFileName(file_name));
	ifstream f(file_name, ios_base::in);
	
	string s;
	while (getline(f, s)) {
		string surname;
		auto it = s.begin();

		while (*it != ' ') {
			surname.push_back(*it);
			it++;
		}

		while (it != s.end()) {
			if (*it != ' ')
				mapSt.insert(pair<string, int>(surname, stoi(s.substr(distance(s.begin(), it), 1))));
			it++;
		}
	
	}

	cout << "Данные успешно загружены." << endl;
}
//-----------------------------------------------------------------------------------------------------
void printMarks(multimap<string, int> mapSt)
{
	auto it = mapSt.begin();
	cout << "Фамилия   | Оценки"
		 << "\n---------------------\n";

	while (it != mapSt.end()) {
		string s = it->first;
		cout << setw(10) << left << s << "| ";

		while (it->first == s) {
			cout << it->second << ' ';
			if (++it == mapSt.end()) break;
		}

		cout << endl;
	}
}
//-----------------------------------------------------------------------------------------------------
void countMarksForEach(multimap<string, int> mapSt)
{
	auto it = mapSt.begin();
	while (it != mapSt.end()) {
		string s = it->first;
		cout << s << " - " << mapSt.count(s) << " оц." << endl;
		while (it->first == s)
			if (++it == mapSt.end()) break;
	}
}
//-----------------------------------------------------------------------------------------------------
void printDebtors(multimap<string, int> mapSt)
{
	cout << "Должники" << endl;
	auto it = mapSt.begin();
	while (it != mapSt.end()) {
		string s = it->first;
		while (it->first == s) {
			if (it->second == 2)
				cout << it->first << endl;
			if (++it == mapSt.end()) break;
		}
	}
}
//-----------------------------------------------------------------------------------------------------
void printAverageMarks(multimap<string, int> mapSt)
{
	auto it = mapSt.begin();
	cout << "Фамилия   | Средний балл"
		 << "\n------------------------\n";

	while (it != mapSt.end()) {
		string s = it->first;
		int count;
		float sum = 0;
		cout << setw(10) << left << s << "| ";

		while (it->first == s) {
			sum += it->second;
			count = mapSt.count(s);
			if (++it == mapSt.end()) break;
		}

		cout << setprecision(2) << sum / count << endl;
		sum -= sum;
	}
}
