#include "funcs.h"

int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);

	int choise;
	multimap<string, int> mapSt;

	
	do
	{
		choise = menu();
		switch (choise)
		{
		case 1: downloadDatabase(mapSt);
			break;
		case 2: printMarks(mapSt);
			break;
		case 3: countMarksForEach(mapSt);
			break;
		case 4: printDebtors(mapSt);
			break;
		case 5: printAverageMarks(mapSt);
			break;
		case 6:
			break;
		default:
			break;
		}
	} while (choise != 6);

	return EXIT_SUCCESS;
}
