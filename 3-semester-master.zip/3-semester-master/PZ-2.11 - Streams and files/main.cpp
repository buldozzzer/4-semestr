#include "Student.h"

int main() {
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);

	int choise;
	vector<Student> vecSt;

	do {
		choise = menu();
		try {
			switch (choise) {
			case 1: createArray(vecSt);
				break;
			case 2: downloadArray(vecSt);
				break;
			case 3: printArray(vecSt);
				break;
			case 4: loadArray(vecSt);
				break;
			case 5:
				break;
			default:
				break;
			}
		}
		catch (const char* s) {
			cout << "Error: " << s << endl;
		}
		
	} while (choise != 5);

	return 0;
}
