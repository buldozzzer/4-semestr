#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <vector>
#include <windows.h>

using namespace std;

class Student
{
private:
	string name;
	int group;
public:
	Student() {
		name.clear();
		group = 0;
	}
	~Student() {
		name.clear();
	}

	friend istream& operator >> (istream& in, Student& s) {
		cout << "Print student info" << endl
			 << "Name: ";

		while (in.get() != '\n');
		getline(in, s.name);

		cout << "Group: ";
		in >> s.group;
		return in;
	}

	friend ostream& operator << (ostream& out, const Student& s) {
		out << setw(14) << left     << s.name
			<< '('		<< s.group	<<  ')' 
			<< endl;
		return out;
	}

	friend ifstream& operator >> (ifstream& in, Student& s) {
		getline(in, s.name);	
		string str;
		getline(in, str);
		s.group = stoi(str);
		return in;
	}

	friend ofstream& operator << (ofstream& out, const Student& s) {
		out << s.name  << '\n'
			<< s.group << '\n';
		return out;
	}
};

template <typename T>
void safeEnter(T &value)
{
	while (!(cin >> value)) {
		cin.clear();
		while (cin.get() != '\n') continue;
		cout << "Input error. Try again: ";
	}
}

int menu() {
	int choise;
	cout << "\n1. Create an array of students\n"
		 << "2. Reading from the file array of the students\n"
		 << "3. Print array of students\n"
		 << "4. Load into the file an array of students\n"
		 << "5. Exit programm\n"
		 << "\nSelect an option: ";
	try {
		safeEnter(choise);
		if ((choise < 1) || (choise > 5)) throw "nonexistent menu option";
	}
	catch (const char* s) {
		cout << "Error: " << s << endl;
	}
	return choise;
}

void createArray(vector<Student>& vecSt) {
	int size;
	cout << "Size: ";
	safeEnter(size);

	if (size < 1) throw "invalid size";

	Student s;
	for (int i = 0; i < size; i++) {
		cin >> s;
		vecSt.emplace_back(s);
	}
}

void downloadArray(vector<Student>& vecSt) {
	if (!vecSt.size()) throw "array is empty";

	string fileName;
	cout << "Input file name: ";
	cin >> fileName;

	ifstream f(fileName, ios_base::in);
	if (!f.is_open()) throw "file does not exist";
	if (f.peek() == EOF) throw "file is empty";

	string s;
	getline(f, s);
	int num = stoi(s);

	Student st;
	for (int i = 0; i < num; i++) {
		f >> st;
		vecSt.emplace_back(st);
	}

	cout << num << " student were added to the array" << endl;
}

void printArray(vector<Student> vecSt) {
	if (!vecSt.size()) throw "array is empty";
	for (auto it : vecSt)
		cout << it;
}

void loadArray(vector<Student>& vecSt) {
	if (!vecSt.size()) throw "array is empty";

	string fileName;
	cout << "Input file name: ";
	cin >> fileName;

	ofstream f(fileName, ios_base::out | ios_base::trunc);

	f << vecSt.size() << '\n';
	for (auto it : vecSt)
		f << it;

	cout << "Array of " << vecSt.size() << " students were loaded onto the " << fileName << endl;
}
