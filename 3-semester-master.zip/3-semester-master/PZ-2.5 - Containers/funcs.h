#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <list>
#include <windows.h>

using namespace std;

bool getFileName(string &file_name)
{
	cout << "Введите название файла: ";
	cin >> file_name;
	fstream f(file_name, ios_base::in);
	if (f.is_open()) {
		f.close();
		return true;
	}
	else {
		cout << "Ошибка открытия файла. Повторите ввод.\n\n";
		return false;
	}
}

vector<string> enterVecStrings()
{
	vector<string> vecStr;
	string str("s");

	cout << "Введите строки." << endl;
	while (!str.empty())
	{
		getline(cin, str);
		if (!str.empty())
			vecStr.push_back(str);
	}

	return vecStr;
}

list<string> getStrings()
{
	string file_name, s;
	while(!getFileName(file_name));
	ifstream f(file_name, ios_base::in);

	char smb[] = {"():;.?!-'/,\"0123456789"};
	list<string> listStr;
	while (getline(f, s, ' ')) {
		for(int i = 0; i < strlen(smb); i++)
			s.erase(remove(s.begin(), s.end(), smb[i]));
		if (!s.empty())
			listStr.push_back(s);
	}
		

	return listStr;
}

int compare(const void* x1, const void* x2)
{
	string* a = (string*)x1;
	string* b = (string*)x2;
	if (a->length() > b->length()) return -1;
	if (a->length() == b->length()) return 0;
	return 1;
}

void sortVecStr(vector<string>& Str) { qsort(&Str, Str.size(), sizeof(string), compare); }

void getStatistic(list<string> list)
{
	int length = 0;
	vector<int> vecCount(6);
	for (auto it = list.begin(); it != list.end(); it++)
	{
		if (it->at(0) == 'б')
			vecCount[0]++;
		if (it->at(0) == 'в')
			vecCount[1]++;
		if (it->at(0) == 'г')
			vecCount[2]++;
		if (it->at(0) == 'д')
			vecCount[3]++;
		if (it->at(0) == 'ж')
			vecCount[4]++;
		if (it->at(0) == 'з')
			vecCount[5]++;
		length += it->length();
	}

	cout << "Статистика." << endl;
	cout << "Общее чисто символов в списке: " << length << endl;
	cout << "Слов на 'б': " << vecCount[0] << endl;
	cout << "Слов на 'в': " << vecCount[1] << endl;
	cout << "Слов на 'г': " << vecCount[2] << endl;
	cout << "Слов на 'д': " << vecCount[3] << endl;
	cout << "Слов на 'ж': " << vecCount[4] << endl;
	cout << "Слов на 'з': " << vecCount[5] << endl;

	multimap<int, string> map;

	for (auto it : list)
		map.insert(pair<int, string>(it.length(), it));

	cout << "Самые короткие слова" << endl;
	auto it = map.begin();
	for (int i = 0; i < 5; i++) {
		cout << it->second << " - " << it->first << endl;
		it++;
	}
}

void printVecStr(vector<string> vecStr)
{
	cout << "-----------------------------" << endl;
	for (auto it : vecStr)
		cout << it << endl;
	cout << "-----------------------------" << endl;
}

void printListStr(list<string> listStr)
{
	cout << "-----------------------------" << endl;
	for (auto it : listStr)
		cout << it << endl;
	cout << "-----------------------------" << endl;
}
