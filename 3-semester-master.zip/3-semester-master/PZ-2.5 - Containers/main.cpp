#include "funcs.h"

int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);

	vector<string> vecStr = enterVecStrings();
	sort(vecStr.begin(), vecStr.end());
	cout << "Отсортированные по длине строки" << endl;
	printVecStr(vecStr);

	list<string> listStr = getStrings();
	int words_counter = listStr.size();

	cout << "Всего слов - " << words_counter << endl;
	printListStr(listStr);

	listStr.unique();
	int unique_words_counter = listStr.size();

	cout << "Уникальных слов - " << unique_words_counter << endl;
	printListStr(listStr);

	getStatistic(listStr);
	system("pause");
	return 0;
}
