#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <windows.h>

using namespace std;

class Student
{
private:
	string name;
	string patronymic;
	string surname;
	int group;
public:
	Student(string n, string p, string s, int g)
	{
		this->name = n;
		this->patronymic = p;
		this->surname = s;
		this->group = g;
	}

	friend ostream& operator<<(ostream& os, const Student& s)
	{
		os << s.surname << " " << s.name << " " << s.patronymic << ", " << s.group;
		return os;
	}

	int getGroup() { return group; }

	void modifySurname() { transform(surname.begin(), surname.end(), surname.begin(), toupper);	}
};
