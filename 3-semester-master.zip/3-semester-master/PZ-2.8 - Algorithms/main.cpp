#include "funcs.h"

int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);

	vector<Student> vecSt;
	int choise;

	do
	{
		choise = menu();
		switch (choise)
		{
		case 1: addStudent(vecSt);
			break;
		case 2: printStudents(vecSt);
			break;
		case 3: modifySurnames(vecSt);
			break;
		case 4: countOneGroupStudents(vecSt);
			break;
		case 5: printGroup(vecSt);
			break;
		case 6:
			break;
		default:
			break;
		}
	} while (choise != 6);
	
	return 0;
}
