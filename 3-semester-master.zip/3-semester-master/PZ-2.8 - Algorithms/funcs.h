#pragma once

#include "Student.h"

template <typename T>
void safeEnter(T &value)
{
	while (!(cin >> value))
	{
		cin.clear();
		while (cin.get() != '\n') continue;
		cout << "Input Error. Try once again: ";
	}
}

int menu()
{
	int choose;
	cout << "\n1. Add new student to the end of the list\n"
	     << "2. Print student list\n"
	     << "3. Modify student's surnames\n"
	     << "4. Count students in current group\n"
		 << "5. Print students from current group\n"
	     << "6. Exit program\n"
	     << "\nSelect an action: ";
	safeEnter(choose);
	return choose;
}

Student getStudent()
{
	string name, patronymic, surname;
	int group;

	cout << "Enter student information.\nName: ";
	cin  >> name;
	cout << "Patronymic: ";
	cin  >> patronymic;
	cout << "Surname: ";
	cin  >> surname;
	cout << "Group: ";
	safeEnter(group);

	return Student(name, patronymic, surname, group);
}

void addStudent(vector<Student>& vecSt) { vecSt.emplace_back(getStudent()); }

void printStudents(vector<Student> vecSt)
{
	cout << "Students list" << endl;
	for_each(vecSt.begin(), vecSt.end(), [](Student s) { cout << s << endl;	});
}

void modifySurnames(vector<Student>& vecSt)
{
	transform(vecSt.begin(), vecSt.end(), vecSt.begin(), [](Student s) {
		s.modifySurname();
		return s; });
	cout << "Surnames successfully modified." << endl;
}

void countOneGroupStudents(vector<Student> vecSt)
{
	int group;
	cout << "Enter group number: ";
	safeEnter(group);
	cout << "Group (" << group << ") contains "
		 << count_if(vecSt.begin(), vecSt.end(), [group](Student s) ->bool { return s.getGroup() == group; })
		 << "peaple." << endl;
}

void printGroup(vector<Student> vecSt)
{
	int group;
	cout << "Enter group number: ";
	safeEnter(group);
	for_each(vecSt.begin(), vecSt.end(), [group](Student s) {
		if (s.getGroup() == group)
			cout << s << endl; });
}
