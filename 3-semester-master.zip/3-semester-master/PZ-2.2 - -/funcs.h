#pragma once

#include "Figure.h"

#define xc     rect.right   //размер поля по x
#define yc     rect.bottom  //размер поля по y
#define pixel  rand() % 255 
#define rnd(x) rand() % (x)

//функция безопасного ввода
template <typename T>
void safeEnter(T &value)
{
	while (!(std::cin >> value))
	{
		std::cin.clear();
		while (std::cin.get() != '\n') continue;
		std::cout << "Ошибка ввода. Попробуйте еще раз: ";
	}
}

int menu()
{
	system("cls");
	int choose;
	std::cout << "1. «Горизонтальные линии».\n"          
		      << "2. «Горизонтальные линии» и фигуры.\n" 
		      << "3. Нарисовать окружность.\n"            
		      << "4. Нарисовать прямоугольник.\n"         
		      << "5. Нарисовать линию.\n"                
		      << "6. Нарисовать телефон.\n"              
		      << "7. Выйти из программы.\n"            
		      << "\nВыберите действие: ";
	safeEnter(choose);
	return choose;
}

void printLines(HDC hdc, RECT rect, int points, int time_s)
{
	Figure** lines = new Figure*[points];
	for (int i = 0; i < points; i++)
		//точки случайного цвета появляются в рандомных местах по всему экрану
		lines[i] = new Point(rnd(xc), rnd(yc), pixel, pixel, pixel);

	for (int i = 0; i < time_s * 20; i++)
	{
		for (int i = 0; i < points; i++)
			lines[i]->write(hdc);
		for (int i = 0; i < points; i++)
			lines[i]->setCoordinates(-1);
		Sleep(50);
	}
}

void printFigures(HDC hdc, RECT rect, int points, int time_s)
{
	Figure** lines = new Figure*[points];
	for (int i = 0; i < points; i++)
	{
		//фигуры повторяются через 4
		if (!(i % 4))   lines[i] = new Point (rnd(xc),  rnd(yc),                    pixel, pixel, pixel);
		if (i % 4 == 1) lines[i] = new Circle(rnd(100), rnd(xc),  rnd(yc),          pixel, pixel, pixel);
		if (i % 4 == 2) lines[i] = new Square(rnd(100), rnd(100), rnd(xc), rnd(yc), pixel, pixel, pixel);
		if (i % 4 == 3) lines[i] = new Line  (rnd(xc),  rnd(yc),  rnd(xc), rnd(yc), pixel, pixel, pixel);
	}

	for (int i = 0; i < time_s * 20; i++)
	{
		for (int i = 0; i < points; i++)
			lines[i]->write(hdc);
		for (int i = 0; i < points; i++)
			lines[i]->setCoordinates(-1);
		Sleep(50);
	}
}

void printCircle(HDC hdc, RECT rect)
{
	int rad;

	std::cout << "Введите радиус окружности: ";
	safeEnter(rad);
	system("cls");

	Figure* figure = new Circle(rad, xc / 2, yc / 2);
	figure->write(hdc);

	Sleep(2000);
}

void printSquare(HDC hdc, RECT rect)
{
	int h, w;

	std::cout << "Введите высоту прямоугольника: ";
	safeEnter(h);
	std::cout << "Введите ширину прямоугольника: ";
	safeEnter(w);
	system("cls");

	Figure* figure = new Square(h, w,  xc / 2, yc / 2);
	figure->write(hdc);

	Sleep(2000);
}

void printLine(HDC hdc, RECT rect)
{
	int x0, y0, x, y;

	std::cout << "Введите x0: ";
	safeEnter(x0);
	std::cout << "Введите y0: ";
	safeEnter(y0);
	std::cout << "Введите x_end: ";
	safeEnter(x);
	std::cout << "Введите y_end: ";
	safeEnter(y);
	system("cls");

	Figure* figure = new Line(x0, y0, x, y);
	figure->write(hdc);

	Sleep(2000);
}

void printTelephone(HDC hdc, RECT rect)
{
	system("cls");

	Circle circle(10, xc / 2, yc / 2);
	circle.write(hdc);
	circle.setRadius(16);
	circle.write(hdc);
	circle.setRadius(32);
	circle.write(hdc);
	circle.setCoord(xc / 2, yc / 2 - 25);
	circle.setRadius(5);
	circle.write(hdc);
	circle.setCoord(xc / 2 - 13, yc / 2 - 20);
	circle.write(hdc);
	circle.setCoord(xc / 2 - 22, yc / 2 - 10);
	circle.write(hdc);
	circle.setCoord(xc / 2 - 23, yc / 2 + 3);
	circle.write(hdc);
	circle.setCoord(xc / 2 - 19, yc / 2 + 15);
	circle.write(hdc);
	circle.setCoord(xc / 2 - 9, yc / 2 + 23);
	circle.write(hdc);
	circle.setCoord(xc / 2 + 3, yc / 2 + 23);
	circle.write(hdc);
	circle.setCoord(xc / 2 + 14, yc / 2 + 19);
	circle.write(hdc);
	circle.setCoord(xc / 2 + 22, yc / 2 + 10);
	circle.write(hdc);
	circle.setCoord(xc / 2 + 24, yc / 2 - 1);
	circle.write(hdc);

	Line line(xc / 2 - 76, yc / 2 - 58, xc / 2 + 76, yc / 2 - 58);
	line.write(hdc);
	line.setStartCoord(xc / 2 + 96, yc / 2 + 58);
	line.setEndCoord(xc / 2 - 96, yc / 2 + 58);
	line.write(hdc);
	line.setEndCoord(xc / 2 + 76, yc / 2 - 58);
	line.write(hdc);
	line.setStartCoord(xc / 2 - 96, yc / 2 + 58);
	line.setEndCoord(xc / 2 - 76, yc / 2 - 58);
	line.write(hdc);

	Square s(10, 192, xc / 2 - 96, yc / 2 + 58);
	s.write(hdc);

	Square square(15, 30, xc / 2 - 76, yc / 2 - (58 + 15));
	square.write(hdc);
	square.setCoord(xc / 2 + (76 - 30), yc / 2 - (58 + 15));
	square.write(hdc);
	square.setOptions(20, 192 + 40 * 2);
	square.setCoord(xc / 2 - (96 + 40), yc / 2 - (58 + 15 + 20));
	square.write(hdc);
	square.setOptions(15, 20);
	square.setCoord(xc / 2 - (96 + 40), yc / 2 - (58 + 15));
	square.write(hdc);
	square.setCoord(xc / 2 + (96 + 40) - 20, yc / 2 - (58 + 15));
	square.write(hdc);

	Sleep(2000);
}
