#pragma once

#include <iostream>
#include <ctime>
#include <cmath>
#include <windows.h>

class Figure
{
protected:
	int x;
	int y;
	COLORREF color;
public:
	//метод смещения точки на на координаты dx и dy
	void setCoordinates(int dx = 0, int dy = 0)
	{
		this->x += dx;
		this->y += dy;
	}
	void setColor(int r, int g, int b)
	{
		this->color = RGB(r, g, b);
	}
	virtual void write(HDC hdc) = 0;
};

class Point : public Figure
{
public:
	Point()
	{
	this->x = 0;
	this->y = 0;
	this->color = RGB(255, 255, 255);
	}
	Point(int dx, int dy, int r = 255, int g = 255, int b = 255)
	{
		this->x = dx;
		this->y = dy;
		this->color = RGB(r, g, b);
	}
	void write(HDC hdc)
	{
		SetPixel(hdc, this->x, this->y, this->color);
	}
};

class Circle : public Figure
{
private:
	int radius;
public:
	Circle(int rad, int x_rad, int y_rad, int r = 255, int g = 255, int b = 255)
	{
		this->radius = rad;
		this->x = x_rad;
		this->y = y_rad;
		this->color = RGB(r, g, b);
	}
	void setRadius(int rad)
	{
		this->radius = rad;
	}
	//поменять координаты центра окружности
	void setCoord(int x1, int y1)
	{
		this->x = x1;
		this->y = y1;
	}
	void write(HDC hdc)
	{
		const double pi = 3.14159265359;
		for (int i = 0; i < 360; i++)
			SetPixel(hdc, this->x + radius * cos(i * pi / 180), this->y + radius * sin(i * pi / 180), this->color);
	}
};

class Square : public Figure
{
private:
	int height;
	int width;
public:
	Square(int h, int w, int dx, int dy, int r = 255, int g = 255, int b = 255)
	{
		this->height = h;
		this->width = w;
		this->x = dx;
		this->y = dy;
		this->color = RGB(r, g, b);
	}
	//изменить высоту и ширину
	void setOptions(int h, int w)
	{
		this->height = h;
		this->width = w;
	}
	//поменять координаты верхнего левого края
	void setCoord(int x1, int y1)
	{
		this->x = x1;
		this->y = y1;
	}
	int getHeight()
	{
		return this->height;
	}
	int getWidth()
	{
		return this->width;
	}
	void write(HDC hdc)
	{
		for (int i = 0; i < height; i++)
		{
			SetPixel(hdc, this->x, this->y + i, this->color);
			SetPixel(hdc, this->x + width, this->y + i, this->color);
		}
		for (int i = 0; i < width; i++)
		{
			SetPixel(hdc, this->x + i, this->y, this->color);
			SetPixel(hdc, this->x + i, this->y + height, this->color);
		}
	}
};

class Line : public Figure
{
private:
	int x0;
	int y0;
public:
	Line(int x1, int y1, int x2, int y2, int r = 255, int g = 255, int b = 255)
	{
		this->x = x1;
		this->y = y1;
		this->x0 = x2;
		this->y0 = y2;
		this->color = RGB(r, g, b);
	}
	void setEndCoord(int x1, int y1)
	{
		this->x0 = x1;
		this->y0 = y1;
	}
	void setStartCoord(int x1, int y1)
	{
		this->x = x1;
		this->y = y1;
	}
	void write(HDC hdc)
	{
		HPEN pen = CreatePen(PS_SOLID, 1, color);
		SelectObject(hdc, pen);
		MoveToEx(hdc, x0, y0, NULL);
		LineTo(hdc, x, y);
		DeleteObject(pen);
	}
};
