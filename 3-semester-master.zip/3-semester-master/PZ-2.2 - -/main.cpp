#include "funcs.h"

int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	srand(time(NULL));

	HWND hwnd = GetConsoleWindow(); // идентификатор окна
	HDC hdc = GetDC(hwnd);          // идентификатор области рисования
	RECT rect;                      // размер окна для рисования
	GetClientRect(hwnd, &rect);     // координаты области рисования

	int choose, points;
	do
	{
		choose = menu();
		switch (choose)
		{
		case 1: std::cout << "Введите количество линий: ";
			safeEnter(points);
			system("cls");
			printLines(hdc, rect, points, 2);
			break;
		case 2: std::cout << "Введите количество фигур: ";
			safeEnter(points);
			system("cls");
			printFigures(hdc, rect, points, 2);
			break;
		case 3: printCircle(hdc, rect);
			break;
		case 4: printSquare(hdc, rect);
			break;
		case 5: printLine(hdc, rect);
			break;
		case 6: printTelephone(hdc, rect); 
			break;
		case 7:
			break;
		default:
			break;
		}
	} while (choose != 7);

	return 0;
}
