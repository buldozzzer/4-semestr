#pragma once
#include <stdexcept>
class MyException : public std::exception
{
private:
	std::string _msg;
public:
	MyException(int type)
	{
		switch (type)
		{
		case 1: _msg = "Invalid options";
			break;
		case 2: _msg = "File does not exist";
			break;
		case 3:
			_msg = "Reserve copy information";
			break;
		default:
			_msg = "Unknown error";
		}
	}
	const char* what() const throw()
	{
		return _msg.c_str();
	}
};
